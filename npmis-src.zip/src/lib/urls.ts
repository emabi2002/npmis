// Single source of truth for external system URLs
export const CYBERCRIME_URL =
  process.env.NEXT_PUBLIC_CYBERCRIME_URL ?? "https://cybercrime-3h6o.vercel.app";
