export interface User {
  badgeNumber: string;
  role: string;
  name: string;
  loginTime: string;
}
